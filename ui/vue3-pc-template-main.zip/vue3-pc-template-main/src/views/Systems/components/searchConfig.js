export const roleSearchConfig = [
    {
        type: 'input',
        title:'角色名称',
        id: 'name',
        placeholder: '请输入角色名称查询'
    },
]